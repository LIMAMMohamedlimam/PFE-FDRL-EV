# HFDRL — Comparaison au budget de 1 000 épisodes

La campagne reprend le simulateur de Mohamed Limam au commit
12a4ff452f157d57b554f1a618ed6f1d6f004e0f, avec la correction des bornes
de puissance avant la résolution du réseau. Elle est distincte du pilote
de 200 épisodes et de son ablation du terme réseau.

## Politiques et protocole

- FedAvg-SAC, HFDRL sans LoRA et HFDRL complet. Les trois politiques
  apprennent avec le terme réseau de poids 0,3. Les graines sont 42, 123,
  456, 789 et 1234 pour chaque politique.
- Chaque entraînement utilise 1 000 épisodes de 24 pas horaires, 20 véhicules,
  une période de chauffe de 2 000 transitions par véhicule, des minibatchs
  de 256 et une mise à jour SAC par transition après la chauffe. Ces
  paramètres correspondent au budget de référence du dépôt.
- La règle sans apprentissage charge dès le début de la session, à la
  puissance admissible maximale. Elle réduit le dernier pas de recharge
  pour s'arrêter à la cible individuelle. Elle ne réalise aucun échange
  de paramètres. La règle utilise directement la cible de charge, qui
  ne figure pas dans l'observation des acteurs SAC.
- Le CSV de prix du dépôt est agrégé par moyenne horaire, puis divisé
  chronologiquement en 316 jours d'entraînement et 79 jours réservés.
  Le scaler min–max et le profil des prix en entrée sont ajustés sur
  l'entraînement. Le coût est un indice construit avec le prix réalisé
  normalisé.
- Les 30 jours de test final, les 20 profils de véhicules par scénario et
  les charges de fond reprennent ceux du pilote. Chaque jour est évalué
  en régime nominal et avec une hausse de charge de fond de 0,8 MW.
  Les résultats d'une politique apprise reposent sur la politique de
  l'épisode 1 000. Les moyennes et intervalles des politiques apprises
  utilisent la graine d'entraînement comme unité statistique.

## Octets et seuil de service

Une évaluation déterministe sur 12 jours réservés, disjoints des jours
de test final, a lieu après chaque centaine d'épisodes. Le seuil fixé avant
les runs est de 80 % de départs à la cible sous charge renforcée. Le
franchissement est le premier point de contrôle où le seuil est atteint.
Cette résolution temporelle de 100 épisodes et le caractère conditionnel
de la comparaison sont à prendre en compte.

Le volume montant véhicule cumule la taille des dictionnaires de tenseurs
des véhicules participants à chaque agrégation. Le volume montant edge
et les tenseurs reçus par les véhicules sont suivis séparément. Les
tailles concernent les valeurs des tenseurs. Le coût réseau complet
dépend en plus de la sérialisation, des en-têtes et des retransmissions.
Le nombre de relais dépend du chemin suivi par le pipeline.

## Reproduction

Dans le dossier de cette archive, avec Python 3.12 et Git, exécuter les
commandes suivantes.

    git clone https://github.com/LIMAMMohamedlimam/PFE-FDRL-EV.git
    git -C PFE-FDRL-EV checkout 12a4ff452f157d57b554f1a618ed6f1d6f004e0f
    git -C PFE-FDRL-EV apply ../pipeline.patch
    git -C PFE-FDRL-EV apply ../battery_feasibility.patch
    git -C PFE-FDRL-EV apply ../round_accounting.patch
    python3 -m venv .venv
    . .venv/bin/activate
    python -m pip install torch==2.7.1 --index-url https://download.pytorch.org/whl/cpu
    python -m pip install -r requirements.txt
    WORKERS=8 PYTHON=python bash run_reference.sh PFE-FDRL-EV
    python audit_lora_initialization.py --repo PFE-FDRL-EV --output results/lora_initialization_audit.json
    python summarize_reference.py --repo PFE-FDRL-EV --directory results

Les résultats bruts contiennent la provenance, les 60 scénarios de test,
les relevés de suivi et les transferts par tour. Les synthèses se trouvent
dans les fichiers suivants.

| Fichier | Contenu |
| --- | --- |
| results/summary.json | Moyennes, intervalles appariés, seuil et contrôles. |
| results/per_episode.csv | Scénarios finaux et bilan d'énergie. |
| results/per_seed.csv | Résultats par méthode, graine et régime de charge. |
| results/monitor.csv | Taux de recharge et volumes cumulés à chaque contrôle. |
| results/threshold.csv | Franchissement et volume correspondant par graine. |
| results/lora_initialization_audit.json | Nombre de bases gelées distinctes à la première agrégation. |
