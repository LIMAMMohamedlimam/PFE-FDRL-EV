"""Audit the actor and critic bases after the first warm-up aggregation."""
import argparse
import hashlib
import random
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch

from reference_study import write_json
from run_grid_reward_study import EvaluationProtocol, PriceDays, SEEDS


class AuditComplete(Exception):
    pass


def frozen_digest(model):
    digest = hashlib.sha256()
    for name, value in model.named_parameters():
        if not value.requires_grad:
            digest.update(name.encode())
            digest.update(value.detach().cpu().numpy().tobytes())
    return digest.hexdigest()


class InitializationAudit(EvaluationProtocol):
    def observe_round(self, episode, agents, *_):
        assert episode == 1
        self.result = {
            "actor_frozen_bases": len({frozen_digest(agent.actor) for agent in agents}),
            "critic_frozen_bases": len({frozen_digest(agent.critic) for agent in agents}),
            "target_critic_frozen_bases": len({frozen_digest(agent.critic_target) for agent in agents}),
            "vehicles": len(agents),
        }
        raise AuditComplete


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    repo = args.repo.resolve()
    sys.path.insert(0, str(repo))
    from training.ComparisonPipeline import run_single_experiment
    from utils.DataLoader import DataGenerator
    from utils.config_loader import get_config

    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    get_config("env")["driver_behavior"]["enabled"] = False
    get_config("training").update(num_episodes=1, num_agents=20, simulation_hours=24)
    get_config("sac")["warmup_steps"] = 2000
    reward = dict(get_config("reward"), w_grid=0.3)
    data = PriceDays(repo / "data" / "iso_ne_prices_real.csv")
    results = []
    for seed in SEEDS:
        torch.manual_seed(seed)
        np.random.seed(seed)
        random.seed(seed)
        audit = InitializationAudit(data, SimpleNamespace(seed=seed, episodes=1,
                                    vehicles=20, test_days=30),
                                    DataGenerator.get_nhts_profile, reward)
        try:
            run_single_experiment(policy="sac", aggregation="fedavg", use_swift=True,
                                  use_lora=True, verbose=False, progress_enabled=False,
                                  evaluation_protocol=audit)
        except AuditComplete:
            results.append({"seed": seed, **audit.result})
        else:
            raise RuntimeError("The first-round hook did not run")
    write_json(args.output, results)


if __name__ == "__main__":
    main()
