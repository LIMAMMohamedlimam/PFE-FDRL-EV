"""Insert the verified reference-budget comparison in the Elsevier manuscript."""
import argparse
import json
import statistics
from pathlib import Path


METHODS = {
    "immediate_charge": "Immediate charging",
    "fedavg_sac": "FedAvg-SAC",
    "hfdrl_no_lora": "HFDRL without LoRA",
    "hfdrl_full": "Full HFDRL",
}
GIB = 1024 ** 3
MIB = 1024 ** 2


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    summary = json.loads(args.summary.read_text())
    assert summary["trained_runs"] == 15 and summary["test_episodes_including_heuristic"] == 960
    assert summary["threshold_pct"] == 80
    stress, nominal = (summary["estimates"][name] for name in ("stress", "nominal"))
    threshold = summary["threshold"]
    text = args.source.read_text()

    def replace(old, new):
        nonlocal text
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)

    def mean(table, method, field):
        return table[method][field]["mean"]

    def target(table, method):
        return f"{mean(table, method, 'target_met_pct'):.1f}"

    def cell(table, method, field, digits=1):
        return f"{mean(table, method, field):.{digits}f}"

    def interval(record, digits=1):
        return (f"{record['mean']:.{digits}f}" + r"\,[" +
                f"{record['ci95_low']:.{digits}f}" + r",\," +
                f"{record['ci95_high']:.{digits}f}]")

    def rows_for(method):
        return [row for row in threshold if row["method"] == method]

    def threshold_count(method):
        return sum(row["reached"] for row in rows_for(method))

    tex_line = "\\\\\n"
    operational_rows = ""
    for method, label in METHODS.items():
        cells = [label, target(nominal, method), target(stress, method),
                 cell(stress, method, "mean_soc_deficit_pp"),
                 cell(stress, method, "normalized_charging_cost_index"),
                 cell(stress, method, "energy_import_kwh"),
                 cell(stress, method, "energy_export_kwh"),
                 cell(stress, method, "voltage_violation_bus_step_pct", 2)]
        operational_rows += " & ".join(cells) + tex_line
    tradeoff_rows = ""
    for method in list(METHODS)[1:]:
        rows = rows_for(method)
        assert len(rows) == 5
        total = [row["final_vehicle_uplink_tensor_bytes"] / GIB for row in rows]
        reached = [row for row in rows if row["reached"]]
        if reached:
            first = statistics.median(row["first_observed_vehicle_uplink_tensor_bytes"] for row in reached) / MIB
            first_ep = statistics.median(row["first_observed_episode"] for row in reached)
            first_str = f"{first:.1f}"
            first_ep_str = f"{first_ep:.0f}"
        else:
            first_str = first_ep_str = "--"
        tradeoff_rows += " & ".join([
            METHODS[method], f"{statistics.mean(total):.3f}", f"{len(reached)}/5", first_ep_str, first_str
        ]) + tex_line

    no_lora = {row["seed"]: row for row in rows_for("hfdrl_no_lora") if row["reached"]}
    both = [row for row in rows_for("hfdrl_full") if row["reached"] and row["seed"] in no_lora]
    if both:
        paired_savings = [
            100 * (1 - row["first_observed_vehicle_uplink_tensor_bytes"] /
                   no_lora[row["seed"]]["first_observed_vehicle_uplink_tensor_bytes"])
            for row in both
        ]
        savings = statistics.mean(paired_savings)
        direction = "lower" if savings >= 0 else "higher"
        matched_text = (
            f"Both SWIFT configurations crossed the monitoring threshold on {len(both)}/5 paired seeds. "
            f"On those seeds, full HFDRL used {abs(savings):.1f}\\% {direction} cumulative vehicle "
            "upload payload on average at the first observed crossing, calculated as the mean of within-seed "
            "relative differences. This estimate is conditional on crossing and depends on the 100-episode "
            "monitoring interval."
        )
        end_text = (
            f"Both SWIFT configurations reached the 80\\% monitoring threshold on {len(both)}/5 paired seeds, "
            f"with {abs(savings):.1f}\\% {direction} cumulative vehicle upload payload for full HFDRL "
            "at the first observed crossing on those seeds."
        )
    else:
        matched_text = (
            "The two SWIFT configurations have no paired seed on which both reach the common threshold. "
            "The fixed-budget payload totals therefore compare communication volumes at the same number "
            "of training episodes. A paired communication estimate at the common service threshold is unavailable."
        )
        end_text = "A paired upload comparison at the common service threshold was unavailable."

    n_fail = summary["failed_test_power_flow_steps"]
    residual = summary["maximum_absolute_energy_residual_kwh"]
    checks = (f"There were {n_fail} non-converged power-flow steps in the 960 final evaluations, "
              f"and the maximum absolute battery-energy residual was \\({residual:.2e}\\)\\,kWh.")
    significand, exponent = f"{residual:.2e}".split("e")
    checks = checks.replace(f"{residual:.2e}", significand + r"\times10^{" + str(int(exponent)) + "}")
    deltas = summary["full_minus_reference"]["stress"]["hfdrl_no_lora"]
    paired_sentence = (
        r"Under increased load, the full-minus-no-LoRA paired difference in target attainment is \(" +
        interval(deltas["target_met_pct"]) + r"\) percentage points, and the corresponding voltage difference is \(" +
        interval(deltas["voltage_violation_bus_step_pct"], 3) +
        r"\) percentage points (mean and 95\% Student interval over five training seeds)."
    )
    if all(mean(stress, m, "target_met_pct") == 100.0 for m in METHODS):
        reference_outcomes = (
            "All four configurations meet every departure target under increased background load. "
            f"The immediate-charging rule has a cost index of "
            f"{cell(stress, 'immediate_charge', 'normalized_charging_cost_index')} per episode "
            f"and imports {cell(stress, 'immediate_charge', 'energy_import_kwh')}\\,kWh. "
            f"Full HFDRL has a cost index of "
            f"{cell(stress, 'hfdrl_full', 'normalized_charging_cost_index')}, imports "
            f"{cell(stress, 'hfdrl_full', 'energy_import_kwh')}\\,kWh and has "
            f"{cell(stress, 'hfdrl_full', 'voltage_violation_bus_step_pct', 2)}\\% out-of-band bus-hours. "
            f"The rule has {cell(stress, 'immediate_charge', 'voltage_violation_bus_step_pct', 2)}\\%."
        )
        reference_abstract = "all three learned policies meet every departure target on the final scenarios."
        reference_conclusion = "all four configurations meet every departure target."
    else:
        reference_outcomes = (
            "Under increased background load, the rule attains " + target(stress, "immediate_charge") +
            r"\% of departure targets. The corresponding rates for FedAvg-SAC, HFDRL without LoRA "
            "and full HFDRL are " + ", ".join(target(stress, m) + r"\%" for m in list(METHODS)[1:]) +
            ", respectively."
        )
        reference_abstract = (
            "full HFDRL attains " + target(stress, "hfdrl_full") + r"\% of departure targets under increased load."
        )
        reference_conclusion = reference_abstract
    sec = r"""
The corrected simulator is used in two campaigns. We first compare communication and charging at the reference training budget. We then examine the explicit congestion term in the separate 200-episode pilot.

\subsubsection{Service and communication at the reference budget}
\label{sec:reference-results}

Table~\ref{tab:reference-service} compares the policies after 1,000 training episodes and the immediate-charging rule. @REFERENCE_OUTCOMES@ @PAIRED@

\begin{table}[!htbp]
\centering\small
\caption{Final evaluation on the corrected simulator at the reference training budget. The two target columns give nominal and increased-load results. All remaining outcomes use increased load. SOC deficit is in percentage points. Energy and cost are per episode. Learned-policy entries average the five training seeds. The deterministic immediate-charging rule is evaluated once per scenario.}
\label{tab:reference-service}
\setlength{\tabcolsep}{3pt}
\begin{tabularx}{\linewidth}{@{}Yrrrrrrr@{}}
\toprule
& \multicolumn{2}{c}{Targets met (\%)} &
\shortstack[r]{SOC\\deficit} & \shortstack[r]{Cost\\index} &
\shortstack[r]{Import\\(kWh)} & \shortstack[r]{Export\\(kWh)} &
\shortstack[r]{Out-of-band\\bus-hours (\%)}\\
\cmidrule(lr){2-3}
Policy & Nominal & Increased & & & & &\\
\midrule
@ROWS@\bottomrule
\end{tabularx}
\end{table}

@CHECKS@

The traffic monitor reports two quantities in Table~\ref{tab:reference-traffic}. The first is the total vehicle upload payload at episode 1,000. The second is the cumulative upload payload at the first scheduled assessment with at least 80\% of departure targets met under increased load. @MATCHED@

\begin{table}[!htbp]
\centering\small
\caption{Cumulative vehicle upload payload at episode 1,000 and at the first observed crossing of the 80\% monitoring threshold. First-crossing medians summarize only seeds that crossed. A dash marks an unobserved crossing.}
\label{tab:reference-traffic}
\setlength{\tabcolsep}{4pt}
\begin{tabularx}{\linewidth}{@{}Yrrrr@{}}
\toprule
Policy & \shortstack[r]{At 1,000\\(GiB)} & \shortstack[r]{Seeds\\crossing} &
\shortstack[r]{Median first\\episode} & \shortstack[r]{Median first\\payload (MiB)}\\
\midrule
@TRAFFIC@\bottomrule
\end{tabularx}
\end{table}

@LORA_AUDIT@

\subsubsection{Congestion-term ablation at the pilot budget}

"""
    for key, value in {
        "REFERENCE_OUTCOMES": reference_outcomes, "PAIRED": paired_sentence, "ROWS": operational_rows,
        "CHECKS": checks, "MATCHED": matched_text, "TRAFFIC": tradeoff_rows,
        "LORA_AUDIT": (
            "An initialization audit of the public SAC LoRA path finds one shared frozen actor base "
            "and 20 distinct frozen critic bases at the first aggregation on each of the five seeds. "
            "The pipeline averages the critic adapter factors while each vehicle retains its own critic base. "
            "The LoRA contrast therefore characterizes this implementation, including its critic initialization."
        ),
    }.items():
        sec = sec.replace("@" + key + "@", value)
    replace(r"\label{sec:pilot-results}" + "\n\n", r"\label{sec:pilot-results}" + "\n" + sec)

    protocol = r"""For the reference-budget comparison, we retain FedAvg-SAC, HFDRL without LoRA and full HFDRL, each with \(w_g=0.3\) and the same five seeds. We run 1,000 episodes with a warm-up of 2,000 transitions and a SAC update at every subsequent transition. The deterministic immediate-charging rule uses the maximum feasible power from session start until reaching the individual SOC target, with the final charging action limited to the energy still needed. The rule uses the declared charge target directly, while the SAC observation in Eq.~\eqref{eq:obs} omits that value. It serves as a charging-service reference and has no learning phase or model exchanges. The four policies use the same final test days, vehicle profiles and feeder loads as the pilot.

During training, we assess each learned policy every 100 episodes after aggregation on 12 separate held-out days under the \(0.8\)\,MW load increase. These dates are disjoint from the final test dates. The monitored policies have no gradient updates and the final test uses the episode-1,000 policies. We set the monitoring threshold to 80\% departure target attainment before the runs. At each assessment we record the cumulative vehicle upload payload, computed from the number of transmitting vehicles and the byte sizes of the tensors passed to aggregation. We record edge uploads and vehicle deliveries separately. The payload accounting concerns model tensors and excludes protocol framing and retransmissions.

"""
    replace(r"\section{Results}", protocol + r"\section{Results}")

    archived_line = (
        r"Corrected policy pilot & FedAvg-SAC, HFDRL without LoRA, full HFDRL and HFDRL without the explicit congestion term & Five paired seeds per configuration, 200 training episodes and 60 shared test scenarios per trained configuration.\\"
    )
    replace(archived_line, archived_line + "\n" + (
        r"Reference-budget comparison & FedAvg-SAC, HFDRL without LoRA, full HFDRL and immediate charging & 1,000 training episodes and five paired seeds for each learned policy. Shared test scenarios and separate service monitoring.\\"
    ))
    replace(
        r"\item \textbf{Charging service and congestion reward.} In a simulator with battery-feasible power, how do the reference policy, the SWIFT path with and without LoRA, and the LoRA policy without the explicit congestion reward term perform on the same test scenarios? We evaluate departure SOC, energy exchange and feeder voltage jointly.",
        r"\item \textbf{Charging service and communication.} With battery power constrained before the feeder solve, how do the learned policies and the immediate-charging rule compare on shared scenarios? We measure payload at a common service threshold and examine the congestion term in a separate pilot."
    )
    begin = text.index("Connected electric vehicles can train charging policies")
    stop = text.index(r"\end{abstract}", begin)
    abstract = (
        r"""Connected vehicles can train charging policies through stations with finite connection times and link capacity. We evaluate hierarchical federated deep reinforcement learning (HFDRL) with Soft Actor-Critic, dwell-based vehicle selection and low-rank adaptation (LoRA). Rank-four adapters reduce the tensor payload per vehicle update from 217.52 to 26.70\,KiB (87.7\%). After accounting for duplicate flat-topology log entries, the modeled hierarchy adds relay traffic and reduces cumulative modeled transfer time under the specified link assumptions. We correct a simulator defect that permits grid injection after battery depletion. In an IEEE 33-bus comparison with five training seeds and 1,000 episodes, """ +
        reference_abstract + " " + end_text +
        r""" A separate 200-episode ablation finds that removing the explicit congestion term reduces the mean departure deficit from 89.7 to 14.6 percentage points of state of charge. The experiments quantify communication alongside charging service and feeder voltage.
"""
    )
    text = text[:begin] + abstract + text[stop:]
    replace(
        r"The policy pilot uses a chronological holdout with training-only tariff scaling and a training-derived hourly profile.",
        r"""The two corrected campaigns use a chronological holdout with training-only tariff scaling and a training-derived hourly profile. The reference-budget comparison adds a charging rule and monitors cumulative upload payload at a common service threshold. The results at that threshold depend on the chosen 80\% criterion, the monitoring interval and the scenarios used for monitoring."""
    )
    replace(
        r"A comparison at the reference training budget with battery-feasible power and matched charging service would establish how the measured payload reduction trades off against charging performance.",
        r"The reference-budget comparison reports the payload needed to cross the service threshold whenever the crossing is observed. The fixed-budget comparison describes charging outcomes and communication volume together for all seeds."
    )
    begin = text.index("Rank-four adapters reduce the per-vehicle federated update from")
    stop = text.index(r"\section*{Code and data availability}", begin)
    text = text[:begin] + (
        r"""Rank-four adapters reduce the per-vehicle update from 217.52 to 26.70\,KiB. The topology audit identifies the extra relay traffic and the lower cumulative modeled transfer time of the hierarchy under the specified link assumptions. On the corrected simulator at the reference training budget, """ +
        reference_conclusion + " " + end_text +
        r""" In the separate 200-episode ablation, removing the congestion term improves charge delivery with variable attainment across seeds. The observations describe the tested reward, network and training settings.

"""
    ) + text[stop:]
    replace(
        r"The companion pilot archive \texttt{HFDRL\_Evaluation\_Ablation\_Reward.zip} contains the simulator patch, evaluation scripts, seed-level and scenario-level outputs, and energy-balance checks.",
        r"""The companion pilot archive \texttt{HFDRL\_Evaluation\_Ablation\_Reward.zip} contains the simulator patch and outputs for the reward ablation. The reference-budget archive \texttt{HFDRL\_Comparaison\_1000\_episodes.zip} contains the aggregation monitor, common-scenario outputs and communication traces."""
    )
    assert "@TRAFFIC@" not in text
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(text)


if __name__ == "__main__":
    main()
