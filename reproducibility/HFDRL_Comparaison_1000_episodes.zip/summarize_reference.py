"""Validate the shared scenarios and summarize completed reference-budget runs."""
import argparse
import csv
import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy.stats import t

from reference_study import METHODS, MONITOR_DAYS, TARGET_PCT
from run_grid_reward_study import SCENARIO_SEED, SEEDS


METRICS = (
    "target_met_pct", "mean_soc_deficit_pp", "mean_final_soc_pct",
    "normalized_charging_cost_index", "energy_import_kwh", "energy_export_kwh",
    "voltage_violation_bus_step_pct", "failed_power_flow_steps",
    "evaluation_reward_common",
)
BYTE_FIELDS = (
    "vehicle_uplink_tensor_bytes", "edge_uplink_tensor_bytes",
    "vehicle_received_tensor_bytes",
)


def average(rows, metric):
    return float(np.mean([r[metric] for r in rows]))


def interval(values):
    mean = float(np.mean(values))
    if len(values) < 2:
        return {"n": len(values), "mean": mean, "ci95_low": None, "ci95_high": None}
    half = float(t.ppf(0.975, len(values) - 1) * np.std(values, ddof=1) / np.sqrt(len(values)))
    return {"n": len(values), "mean": mean, "ci95_low": mean - half, "ci95_high": mean + half}


def write_csv(path, rows):
    with path.open("w", newline="") as out:
        writer = csv.DictWriter(out, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def scenario_identities(rows):
    return [(r["scenario_id"], r["date"], r["condition"], r["departures"]) for r in rows]


def validate_rounds(run):
    checkpoints = run["checkpoints"]
    rounds = run["communication_rounds"]
    assert [row["episode"] for row in rounds] == list(range(1, 1001))
    assert [row["episode"] for row in checkpoints] == list(range(100, 1001, 100))
    assert len(run["training_episode_rewards"]) == 1000
    payload = run["training"]["payload_bytes_per_vehicle"]
    for row in rounds:
        assert row["vehicle_uplink_tensor_bytes"] == row["vehicle_uploads"] * payload
        assert row["edge_uplink_tensor_bytes"] == row["edge_uploads"] * payload
        assert row["vehicle_received_tensor_bytes"] == 20 * payload
        assert 0 < row["vehicle_uploads"] <= 20
        if run["method"] == "fedavg_sac":
            assert row["vehicle_uploads"] == 20
    for key in BYTE_FIELDS:
        assert run["training"][key] == sum(r[key] for r in rounds)
        assert all(row[key] == sum(r[key] for r in rounds[:row["episode"]]) for row in checkpoints)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", type=Path, required=True)
    parser.add_argument("--repo", type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.repo.resolve()))
    from utils.DataLoader import DataGenerator

    directory = args.directory
    greedy = json.loads((directory / "immediate_charge.json").read_text())
    runs = {
        (method, seed): json.loads((directory / f"{method}_{seed}.json").read_text())
        for method in METHODS for seed in SEEDS
    }
    final_identities = scenario_identities(greedy["episodes"])
    final_dates = {r["date"] for r in greedy["episodes"]}
    assert len(final_identities) == 60 and len(final_dates) == 30
    validation = scenario_identities(runs["hfdrl_full", SEEDS[0]]["checkpoints"][0]["scenarios"])
    assert len(validation) == MONITOR_DAYS and final_dates.isdisjoint({x[1] for x in validation})
    for (method, seed), run in runs.items():
        assert (run["method"], run["seed"]) == (method, seed)
        assert scenario_identities(run["episodes"]) == final_identities
        assert run["code_commit"] == greedy["code_commit"]
        assert run["pipeline_sha256"] == greedy["pipeline_sha256"]
        assert run["data"] == greedy["data"]
        for k, expected in {"training_episodes": 1000, "sac_warmup": 2000, "sac_update_every": 1,
                            "sac_batch_size": 256, "target_threshold_pct": TARGET_PCT}.items():
            assert run["settings"][k] == expected
        validate_rounds(run)
        for point in run["checkpoints"]:
            assert scenario_identities(point["scenarios"]) == validation
            assert point["target_met_pct"] == average(point["scenarios"], "target_met_pct")
    all_runs = [greedy, *runs.values()]
    np.random.seed(SCENARIO_SEED)
    initial = [
        60.0 * sum(row["soc_init"] for row in DataGenerator.get_nhts_profile(20))
        for _ in range(30)
    ]
    episode_rows = []
    seed_rows = []
    monitor_rows = []
    threshold_rows = []
    by_method = defaultdict(dict)
    failures = 0
    for run in all_runs:
        method, seed = run["method"], run["seed"]
        for row in run["episodes"]:
            end = row["mean_final_soc_pct"] / 100 * row["departures"] * 60.0
            imported = row["energy_import_kwh"]
            exported = row["energy_export_kwh"]
            residual = end - initial[row["scenario_id"] // 2] - 0.95 * (imported - exported)
            assert abs(residual) < 1e-7, (method, seed, row["scenario_id"], residual)
            failures += row["failed_power_flow_steps"]
            episode_rows.append({"method": method, "seed": seed, **row,
                                 "energy_balance_residual_kwh": residual})
        for condition in ("nominal", "stress"):
            rows = [r for r in run["episodes"] if r["condition"] == condition]
            values = {k: average(rows, k) for k in METRICS}
            by_method[method, condition][seed] = values
            seed_rows.append({"method": method, "seed": seed, "condition": condition, **values})
        if seed is None:
            continue
        points = run["checkpoints"]
        monitor_rows.extend({"method": method, "seed": seed,
                             **{k: v for k, v in point.items() if k != "scenarios"}}
                            for point in points)
        first = next((point for point in points if point["target_met_pct"] >= TARGET_PCT), None)
        threshold_rows.append({
            "method": method, "seed": seed, "reached": first is not None,
            "first_observed_episode": first["episode"] if first else None,
            "first_observed_vehicle_uplink_tensor_bytes": first[BYTE_FIELDS[0]] if first else None,
            "final_vehicle_uplink_tensor_bytes": run["training"][BYTE_FIELDS[0]],
            "final_edge_uplink_tensor_bytes": run["training"][BYTE_FIELDS[1]],
            "final_vehicle_received_tensor_bytes": run["training"][BYTE_FIELDS[2]],
            "best_monitored_attainment_pct": max(point["target_met_pct"] for point in points),
        })
    estimates = {}
    deltas = {}
    for condition in ("nominal", "stress"):
        estimates[condition] = {
            method: {k: interval([v[k] for v in by_method[method, condition].values()]) for k in METRICS}
            for method in ("immediate_charge", *METHODS)
        }
        deltas[condition] = {
            other: {k: interval([by_method["hfdrl_full", condition][seed][k]
                                 - by_method[other, condition][seed][k] for seed in SEEDS])
                    for k in METRICS}
            for other in ("hfdrl_no_lora", "fedavg_sac")
        }
    lora_audit = json.loads((directory / "lora_initialization_audit.json").read_text())
    assert {row["seed"] for row in lora_audit} == set(SEEDS)
    assert all(row["actor_frozen_bases"] == 1 and row["critic_frozen_bases"] == row["vehicles"] == 20
               for row in lora_audit)
    summary = {
        "lora_initialization_audit": lora_audit,
        "test_scenarios_per_policy": len(final_identities),
        "trained_runs": len(runs), "test_episodes_including_heuristic": len(episode_rows),
        "maximum_absolute_energy_residual_kwh": max(abs(r["energy_balance_residual_kwh"]) for r in episode_rows),
        "failed_test_power_flow_steps": failures, "estimates": estimates,
        "full_minus_reference": deltas,
        "threshold": threshold_rows, "threshold_pct": TARGET_PCT,
        "test_dates": sorted(final_dates), "monitor_dates": [x[1] for x in validation],
    }
    (directory / "summary.json").write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n")
    write_csv(directory / "per_episode.csv", episode_rows)
    write_csv(directory / "per_seed.csv", seed_rows)
    write_csv(directory / "monitor.csv", monitor_rows)
    write_csv(directory / "threshold.csv", threshold_rows)
    print(f"Validated {len(runs)} trainings and {len(episode_rows)} final evaluation episodes.")
    for row in threshold_rows:
        print(row["method"], row["seed"], row["first_observed_episode"], round(row["best_monitored_attainment_pct"], 2))


if __name__ == "__main__":
    main()
