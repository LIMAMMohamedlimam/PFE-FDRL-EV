"""Paired out-of-time evaluation for the HFDRL PFE."""
import argparse
import hashlib
import json
import random
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import pandapower as pp
import torch


CONDITIONS = {
    "fedavg_sac": (False, False, 0.3),
    "hfdrl_no_lora": (True, False, 0.3),
    "hfdrl_full": (True, True, 0.3),
    "hfdrl_no_grid_reward": (True, True, 0.0),
}
SEEDS = (42, 123, 456, 789, 1234)
SCENARIO_SEED = 830515
HOURS = 24


class PriceDays:
    def __init__(self, csv_file):
        raw = pd.read_csv(csv_file, parse_dates=["timestamp"])
        hourly = raw.groupby("timestamp", sort=True)["price"].mean()
        days = hourly.groupby(hourly.index.normalize(), sort=True)
        complete = [
            (date, series.to_numpy())
            for date, series in days
            if list(series.index.hour) == list(range(HOURS))
        ]
        dates, rows = zip(*complete)
        self.dates = pd.DatetimeIndex(dates)
        price = np.asarray(rows, dtype=float)
        split = int(0.8 * len(price))
        train = price[:split]
        lo = float(train.min())
        hi = float(train.max())
        if not np.isfinite(price).all() or hi <= lo:
            raise ValueError("Expected finite prices and a nonconstant training range")
        self.train = (train - lo) / (hi - lo)
        self.test = (price[split:] - lo) / (hi - lo)
        self.test_dates = self.dates[split:]
        self.train_hourly = self.train.mean(axis=0)
        self.forecasts = [
            [float(self.train_hourly[(hour + offset) % HOURS]) for offset in range(5)]
            for hour in range(HOURS)
        ]
        self.metadata = {
            "csv_sha256": hashlib.sha256(csv_file.read_bytes()).hexdigest(),
            "raw_rows": len(raw),
            "unique_hours": len(hourly),
            "same_timestamp_reducer": "arithmetic mean",
            "dropped_incomplete_days": [
                str(date.date()) for date in days.groups if date not in self.dates
            ],
            "train_days": len(self.train),
            "holdout_days": len(self.test),
            "train_start": str(self.dates[0].date()),
            "train_end": str(self.dates[split - 1].date()),
            "holdout_start": str(self.test_dates[0].date()),
            "holdout_end": str(self.test_dates[-1].date()),
            "scaler_train_min": lo,
            "scaler_train_max": hi,
            "forecast": "hour-of-day average from training only, modulo 24",
            "reward_and_cost_tariff": "realized same-day normalized price; holdout values not clipped",
        }


class EvaluationProtocol:
    def __init__(self, data, args, generate_profiles, eval_reward):
        self.data = data
        self.eval_reward = eval_reward
        train_rng = np.random.default_rng(np.random.SeedSequence([args.seed, 478]))
        self.train_day_ids = train_rng.integers(len(data.train), size=args.episodes)
        self.train_load = train_rng.normal(3.5, 0.2, size=(args.episodes, HOURS))
        rng = np.random.default_rng(SCENARIO_SEED)
        test_ids = np.linspace(0, len(data.test) - 1, args.test_days, dtype=int)
        np_state = np.random.get_state()
        try:
            np.random.seed(SCENARIO_SEED)
            self.scenarios = [
                (day_id, rng.normal(3.5, 0.2, size=HOURS), generate_profiles(args.vehicles))
                for day_id in test_ids
            ]
        finally:
            np.random.set_state(np_state)
        self.eval_cases = [
            (day_id, condition, background + offset, profiles)
            for day_id, background, profiles in self.scenarios
            for condition, offset in (("nominal", 0.0), ("stress", 0.8))
        ]
        self.rows = []
        self.train_rewards = []
        self.training = {}
        self.started = time.monotonic()

    def price_and_forecast(self, phase, episode, hour):
        if phase == "train":
            price = self.data.train[self.train_day_ids[episode], hour]
        else:
            price = self.data.test[self.eval_cases[episode][0], hour]
        return float(price), self.data.forecasts[hour]

    def training_load(self, episode, hour):
        return float(self.train_load[episode, hour])

    def evaluation_load(self, episode, hour):
        return float(self.eval_cases[episode][2][hour])

    def progress(self, done, total, reward):
        self.train_rewards.append(float(reward))
        if done in (1, total) or done % 25 == 0:
            print(f"Train {done}/{total} at {time.monotonic() - self.started:.1f}s", flush=True)

    def capture_training(self, agents, metrics):
        params = agents[0].get_parameters()
        self.training = {
            "payload_bytes_per_vehicle": int(sum(v.nbytes for v in params.values())),
            "transitions_per_vehicle": [int(a.total_steps) for a in agents],
            "gradient_updates_per_vehicle": [
                max(0, a.total_steps // a.update_every
                    - (max(a.warmup_steps, a.batch_size) - 1) // a.update_every)
                for a in agents
            ],
            "last_20_train_reward_mean": float(np.mean(metrics.episode_rewards[-20:])),
            "last_20_train_cost_index_mean": float(np.mean(metrics.episode_costs[-20:])),
            "mean_swift_selected_clients": (
                float(np.mean([row["n_selected"] for row in metrics.swift_log]))
                if metrics.swift_log else None
            ),
        }
        print("Training complete; evaluating fixed scenarios", flush=True)

    def begin_episode(self, index, envs):
        profiles = self.eval_cases[index][3]
        for env, profile in zip(envs, profiles, strict=True):
            if env.driver_behavior_enabled:
                raise ValueError("Common evaluation assumes episode-relative sessions")
            env.reset(
                initial_soc=profile["soc_init"],
                soc_req=profile["soc_req"],
                t_dep=profile["duration"],
            )
            env.reward_config = self.eval_reward
        self.terminal = []
        self.cost = self.energy_import = self.energy_export = 0.0
        self.loads = []
        self.ev_loads = []
        self.voltages = []
        self.grid_failures = 0

    def record_grid(self, grid, converged, total_load, ev_load):
        self.loads.append(float(total_load))
        self.ev_loads.append(float(ev_load))
        if converged:
            self.voltages.append(grid.net.res_bus.vm_pu.to_numpy().copy())
        else:
            self.grid_failures += 1

    def record_vehicle(self, env, done, energy_cost):
        energy = env.episode_log[-1]["charging_power"] * env.dt
        self.energy_import += max(energy, 0.0)
        self.energy_export += max(-energy, 0.0)
        self.cost += float(energy_cost)
        if done:
            self.terminal.append((float(env.soc), float(env.soc_req)))

    def finish_episode(self, index, reward):
        day_id, condition, _, profiles = self.eval_cases[index]
        if len(self.terminal) != len(profiles):
            raise ValueError(f"Missing departures in scenario {index}")
        terminal = np.asarray(self.terminal)
        soc, target = terminal.T
        voltages = np.asarray(self.voltages)
        valid = voltages.size > 0
        outside = (voltages < 0.90) | (voltages > 1.10)
        self.rows.append({
            "scenario_id": index,
            "date": str(self.data.test_dates[day_id].date()),
            "condition": condition,
            "evaluation_reward_common": float(reward),
            "normalized_charging_cost_index": self.cost,
            "departures": len(soc),
            "mean_final_soc_pct": float(100 * soc.mean()),
            "target_met_pct": float(100 * np.mean(soc + 1e-10 >= target)),
            "mean_soc_deficit_pp": float(100 * np.maximum(target - soc, 0).mean()),
            "energy_import_kwh": self.energy_import,
            "energy_export_kwh": self.energy_export,
            "mean_abs_voltage_deviation_pu": float(np.abs(voltages - 1).mean()) if valid else None,
            "min_voltage_pu": float(voltages.min()) if valid else None,
            "voltage_violation_bus_step_pct": float(100 * outside.mean()) if valid else None,
            "voltage_violation_time_step_pct": float(100 * outside.any(axis=1).mean()) if valid else None,
            "failed_power_flow_steps": self.grid_failures,
            "grid_ramp_sd_mw": float(np.diff(self.loads).std()),
            "ev_ramp_sd_mw": float(np.diff(self.ev_loads).std()),
            "peak_grid_load_mw": max(self.loads),
        })
        if (index + 1) % 20 == 0 or index + 1 == len(self.eval_cases):
            print(f"Eval {index + 1}/{len(self.eval_cases)} at {time.monotonic() - self.started:.1f}s", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--method", choices=CONDITIONS, required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--episodes", type=int, default=250)
    parser.add_argument("--test-days", type=int, default=30)
    parser.add_argument("--vehicles", type=int, default=20)
    parser.add_argument("--warmup", type=int, default=512)
    parser.add_argument("--batch-size", type=int, default=256)
    parser.add_argument("--update-every", type=int, default=4)
    args = parser.parse_args()

    repo = args.repo.resolve()
    sys.path.insert(0, str(repo))
    from training.ComparisonPipeline import run_single_experiment
    from utils.DataLoader import DataGenerator
    from utils.config_loader import get_config

    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    random.seed(args.seed)

    swift, lora, grid_weight = CONDITIONS[args.method]
    data = PriceDays(repo / "data" / "iso_ne_prices_real.csv")
    if not 1 <= args.test_days <= len(data.test):
        raise ValueError("Number of requested test days is outside the holdout size")
    base_reward = dict(get_config("reward"))
    evaluation_reward = dict(base_reward, w_grid=0.3)
    get_config("reward")["w_grid"] = grid_weight
    get_config("env")["driver_behavior"]["enabled"] = False
    get_config("training").update(
        num_episodes=args.episodes,
        num_test_episodes=2 * args.test_days,
        num_agents=args.vehicles,
        simulation_hours=HOURS,
    )
    get_config("sac").update(
        warmup_steps=args.warmup, batch_size=args.batch_size, update_every=args.update_every
    )

    protocol = EvaluationProtocol(data, args, DataGenerator.get_nhts_profile, evaluation_reward)
    run_single_experiment(
        policy="sac", aggregation="fedavg", use_swift=swift, use_lora=lora,
        verbose=False, progress_enabled=False, evaluation_protocol=protocol,
    )
    if len(protocol.rows) != 2 * args.test_days:
        raise RuntimeError("Evaluation did not finish")
    result = {
        "method": args.method,
        "seed": args.seed,
        "code_commit": subprocess.check_output(
            ["git", "-C", str(repo), "rev-parse", "HEAD"], text=True
        ).strip(),
        "pipeline_sha256": hashlib.sha256((repo / "training/ComparisonPipeline.py").read_bytes()).hexdigest(),
        "torch_version": torch.__version__,
        "pandapower_version": pp.__version__,
        "settings": {
            "training_episodes": args.episodes, "test_days": args.test_days,
            "vehicles": args.vehicles, "sac_warmup": args.warmup,
            "sac_batch_size": args.batch_size, "sac_update_every": args.update_every,
            "swift": swift, "lora": lora, "training_grid_weight": grid_weight,
            "evaluation_grid_weight": 0.3, "common_scenario_seed": SCENARIO_SEED,
            "stress_background_load_offset_mw": 0.8,
        },
        "data": data.metadata,
        "training": protocol.training,
        "training_episode_rewards": protocol.train_rewards,
        "episodes": protocol.rows,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    tmp = args.output.with_suffix(".tmp")
    tmp.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
    tmp.replace(args.output)
    print(f"Completed {args.method} / seed {args.seed}", flush=True)


if __name__ == "__main__":
    main()
