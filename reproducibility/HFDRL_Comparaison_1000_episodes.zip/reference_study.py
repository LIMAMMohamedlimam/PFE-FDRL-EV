"""Reference-budget policy comparison and cumulative tensor accounting."""
import argparse
import copy
import hashlib
import json
import random
import subprocess
import sys
from pathlib import Path

import numpy as np
import pandapower as pp
import torch

from run_grid_reward_study import CONDITIONS, HOURS, SCENARIO_SEED, EvaluationProtocol, PriceDays


METHODS = ("fedavg_sac", "hfdrl_no_lora", "hfdrl_full")
TARGET_PCT = 80.0
MONITOR_DAYS = 12
MONITOR_SEED = 122783


def write_json(path, result):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    tmp.replace(path)


def evaluate(protocol, agents=None):
    """Run the same feeder and SOC accounting for monitor policies or a fixed rule."""
    from env.EVClientEnv import EVClientEnv
    from env.GridEnv import GridEnv
    from training.ComparisonPipeline import _action_to_power
    from utils.config_loader import get_config

    config = get_config("env")
    vehicles = len(protocol.eval_cases[0][3])
    envs = [EVClientEnv({"capacity": config.get("battery_capacity", 60.0),
                         "dt": 1.0}) for _ in range(vehicles)]
    grid = GridEnv(get_config("training").get("grid_type", "case33bw"))
    for index in range(len(protocol.eval_cases)):
        grid.reset()
        protocol.begin_episode(index, envs)
        active = [True] * vehicles
        previous_grid = previous_voltage = total_reward = 0.0
        for hour in range(HOURS):
            price, forecast = protocol.price_and_forecast("test", index, hour)
            background = protocol.evaluation_load(index, hour)
            injections = {}
            powers = {}
            for i, env in enumerate(envs):
                if not active[i]:
                    continue
                agent = None if agents is None else agents[i]
                if agent is None:
                    # Charge immediately at the maximum rate until the exact target.
                    gap_kw = max(0.0, env.soc_req - env.soc) * env.capacity / (env.eta * env.dt)
                    raw = min(1.0, gap_kw / env._get_max_power(env.soc))
                else:
                    raw = agent.get_action(env.get_state(previous_grid, previous_voltage, forecast),
                                           eval_mode=True)
                powers[i] = _action_to_power(agent, raw, env, "sac")
                bus = (i % 30) + 2
                injections[bus] = injections.get(bus, 0.0) + powers[i] / 1000.0
            previous_grid, info = grid.step(injections, background)
            previous_voltage = info["max_voltage"] - 1.0
            ev_load = float(sum(injections.values()))
            protocol.record_grid(grid, info["converged"], background + ev_load, ev_load)
            for i, power in powers.items():
                reward, done, _, cost = envs[i].step(power, previous_grid, previous_voltage, price)
                total_reward += reward
                protocol.record_vehicle(envs[i], done, cost)
                active[i] = not done
        protocol.finish_episode(index, total_reward)
    return protocol.rows


class ReferenceProtocol(EvaluationProtocol):
    def __init__(self, data, args, generate_profiles, eval_reward):
        super().__init__(data, args, generate_profiles, eval_reward)
        self.monitor_every = args.monitor_every
        self.partial = args.output.with_name(args.output.stem + "_trace.json")
        holdout_ids = [i for i in range(len(data.test)) if i not in {row[0] for row in self.scenarios}]
        rng = np.random.default_rng(MONITOR_SEED)
        py_state = np.random.get_state()
        try:
            np.random.seed(MONITOR_SEED)
            self.monitor_cases = [
                (holdout_ids[i], "stress", rng.normal(3.5, 0.2, size=HOURS) + 0.8,
                 generate_profiles(args.vehicles))
                for i in np.linspace(0, len(holdout_ids) - 1, MONITOR_DAYS, dtype=int)
            ]
        finally:
            np.random.set_state(py_state)
        self.rounds = []
        self.checkpoints = []
        self.cumulative = {
            "vehicle_uplink_tensor_bytes": 0,
            "edge_uplink_tensor_bytes": 0,
            "vehicle_received_tensor_bytes": 0,
        }
        self.payload_bytes = None

    def observe_round(self, episode, agents, n_uploads, edges, global_params):
        payload = sum(value.nbytes for value in global_params.values())
        if self.payload_bytes is None:
            sizes = {sum(value.nbytes for value in agent.get_parameters().values()) for agent in agents}
            if sizes != {payload}:
                raise ValueError("Vehicle parameter dictionaries differ in size")
            self.payload_bytes = payload
        if payload != self.payload_bytes:
            raise ValueError("Tensor layout changed during training")
        increments = {
            "vehicle_uplink_tensor_bytes": n_uploads * payload,
            "edge_uplink_tensor_bytes": sum(v.nbytes for edge in edges for v in edge["params"].values()),
            "vehicle_received_tensor_bytes": len(agents) * payload,
        }
        for key, value in increments.items():
            self.cumulative[key] += value
        self.rounds.append({"episode": episode, "vehicle_uploads": n_uploads,
                            "edge_uploads": len(edges), **increments})
        if episode % self.monitor_every == 0 or episode == len(self.train_day_ids):
            monitor = copy.copy(self)
            monitor.eval_cases = self.monitor_cases
            monitor.rows = []
            rows = evaluate(monitor, agents)
            score = float(np.mean([row["target_met_pct"] for row in rows]))
            self.checkpoints.append({"episode": episode, **self.cumulative,
                                     "target_met_pct": score, "scenarios": rows})
            write_json(self.partial, {"rounds": self.rounds, "checkpoints": self.checkpoints,
                                      "training_episode_rewards": self.train_rewards})
            print(f"Monitor at {episode}: {score:.2f}% targets; "
                  f"{self.cumulative['vehicle_uplink_tensor_bytes']} vehicle upload bytes", flush=True)

    def capture_training(self, agents, metrics):
        super().capture_training(agents, metrics)
        assert self.payload_bytes == self.training["payload_bytes_per_vehicle"]
        self.training.update(self.cumulative)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--method", choices=(*METHODS, "immediate_charge"), required=True)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--episodes", type=int, default=1000)
    parser.add_argument("--monitor-every", type=int, default=100)
    parser.add_argument("--warmup", type=int, default=2000)
    parser.add_argument("--update-every", type=int, default=1)
    args = parser.parse_args()
    args.test_days = 30
    args.vehicles = 20
    args.batch_size = 256
    repo = args.repo.resolve()
    sys.path.insert(0, str(repo))
    from training.ComparisonPipeline import run_single_experiment
    from utils.DataLoader import DataGenerator
    from utils.config_loader import get_config

    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    random.seed(args.seed)
    get_config("env")["driver_behavior"]["enabled"] = False
    get_config("reward")["w_grid"] = 0.3
    reward = dict(get_config("reward"))
    data = PriceDays(repo / "data" / "iso_ne_prices_real.csv")

    if args.method == "immediate_charge":
        protocol = EvaluationProtocol(data, args, DataGenerator.get_nhts_profile, reward)
        evaluate(protocol)
        protocol.training = {"vehicle_uplink_tensor_bytes": 0}
        checkpoints = rounds = []
        swift = lora = False
    else:
        get_config("training").update(num_episodes=args.episodes, num_test_episodes=2 * args.test_days,
                                       num_agents=args.vehicles, simulation_hours=HOURS)
        get_config("sac").update(warmup_steps=args.warmup, batch_size=args.batch_size,
                                  update_every=args.update_every)
        protocol = ReferenceProtocol(data, args, DataGenerator.get_nhts_profile, reward)
        swift, lora, _ = CONDITIONS[args.method]
        run_single_experiment(policy="sac", aggregation="fedavg", use_swift=swift, use_lora=lora,
                              verbose=False, progress_enabled=False, evaluation_protocol=protocol)
        checkpoints, rounds = protocol.checkpoints, protocol.rounds
        assert len(rounds) == args.episodes
        assert checkpoints[-1]["episode"] == args.episodes
    assert len(protocol.rows) == 2 * args.test_days
    result = {
        "method": args.method, "seed": None if args.method == "immediate_charge" else args.seed,
        "code_commit": subprocess.check_output(["git", "-C", str(repo), "rev-parse", "HEAD"],
                                               text=True).strip(),
        "pipeline_sha256": hashlib.sha256((repo / "training/ComparisonPipeline.py").read_bytes()).hexdigest(),
        "torch_version": torch.__version__, "pandapower_version": pp.__version__,
        "settings": {"training_episodes": 0 if args.method == "immediate_charge" else args.episodes,
                     "test_days": args.test_days, "vehicles": args.vehicles, "sac_warmup": args.warmup,
                     "sac_batch_size": args.batch_size, "sac_update_every": args.update_every,
                     "swift": swift, "lora": lora, "training_grid_weight": 0.3,
                     "evaluation_grid_weight": 0.3, "common_scenario_seed": SCENARIO_SEED,
                     "stress_background_load_offset_mw": 0.8, "monitor_every": args.monitor_every,
                     "monitor_days": MONITOR_DAYS, "monitor_seed": MONITOR_SEED,
                     "target_threshold_pct": TARGET_PCT},
        "data": data.metadata, "training": protocol.training,
        "training_episode_rewards": protocol.train_rewards, "checkpoints": checkpoints,
        "communication_rounds": rounds, "episodes": protocol.rows,
    }
    write_json(args.output, result)
    print(f"Completed {args.method} / seed {args.seed}", flush=True)


if __name__ == "__main__":
    main()
