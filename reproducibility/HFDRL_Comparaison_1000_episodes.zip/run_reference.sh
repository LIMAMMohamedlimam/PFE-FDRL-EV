#!/usr/bin/env bash
set -euo pipefail
study=$(cd "$(dirname "$0")" && pwd)
repo=$(cd "$1" && pwd)
python=$(printenv PYTHON || printf python3)
workers=$(printenv WORKERS || printf 8)
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
export HFDRL_REPO="$repo" HFDRL_STUDY="$study" HFDRL_PYTHON="$python"
mkdir -p "$study/results" "$study/logs"
if [ ! -s "$study/results/immediate_charge.json" ]; then
    "$python" "$study/reference_study.py" --repo "$repo" --method immediate_charge \
        --output "$study/results/immediate_charge.json" > "$study/logs/immediate_charge.log" 2>&1
fi
for seed in 42 123 456 789 1234; do
    for method in fedavg_sac hfdrl_no_lora hfdrl_full; do
        printf '%s %s\n' "$seed" "$method"
    done
done | xargs -n 2 -P "$workers" bash -c '
    set -e
    seed=$1
    method=$2
    printf -v tag "%s_%s" "$method" "$seed"
    out="$HFDRL_STUDY/results/$tag.json"
    if [ -s "$out" ]; then
        printf "Using completed %s\n" "$tag"
        exit
    fi
    PYTHONHASHSEED="$seed" "$HFDRL_PYTHON" "$HFDRL_STUDY/reference_study.py" \
        --repo "$HFDRL_REPO" --method "$method" --seed "$seed" --output "$out" \
        > "$HFDRL_STUDY/logs/$tag.log" 2>&1
    printf "Completed %s\n" "$tag"
' _
