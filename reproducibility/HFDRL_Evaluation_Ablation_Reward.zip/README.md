# HFDRL — Évaluation commune et ablation du terme réseau

Cette campagne pilote reprend le pipeline SAC, FedAvg, SWIFT, LoRA et la
résolution de flux AC du dépôt de Mohamed Limam. Le commit de départ est
12a4ff452f157d57b554f1a618ed6f1d6f004e0f. Les résultats sont de nouvelles
simulations et forment un ensemble distinct des tableaux archivés du PFE.

## Deux versions du simulateur

La première campagne sert de diagnostic. À la limite basse, le code public
peut enregistrer une exportation d'énergie alors que le SOC est déjà nul.
À la limite haute, il peut encore comptabiliser une charge alors que le
SOC est déjà de 1. La puissance commandée entre dans le calcul de flux
avant l'écrêtage du SOC.

La seconde campagne applique une correction ciblée au pipeline de
comparaison, avant le calcul de flux, à l'entraînement comme à
l'évaluation. Pour une batterie de capacité C, de SOC z, d'efficacité eta
et un pas dt, la puissance appliquée est bornée à la fois par la puissance
du chargeur et par l'intervalle [-z C/(eta dt), (1-z) C/(eta dt)] du modèle
de batterie existant. Le calcul de flux et le bilan de batterie reçoivent
cette même puissance. Les autres choix du modèle sont repris à
l'identique. Les deux campagnes utilisent les mêmes méthodes, graines,
scénarios et paramètres d'apprentissage.

## Protocole

| Méthode | SWIFT | LoRA | Poids du terme réseau à l'entraînement |
| --- | --- | --- | ---: |
| FedAvg-SAC | Non | Non | 0,3 |
| HFDRL sans LoRA | Oui | Non | 0,3 |
| HFDRL complet | Oui | Oui | 0,3 |
| HFDRL sans terme réseau | Oui | Oui | 0 |

Les deux variantes d'ablation gardent les mêmes observations du réseau,
les mêmes termes de rampe et de suivi de charge et les mêmes autres
paramètres. Le terme ablaté vaut −w_grid × |énergie échangée| × signal de
congestion. Il pénalise les deux sens d’échange. Les quatre variantes sont évaluées avec une fonction de
récompense commune, au poids réseau de 0,3. La comparaison LoRA porte sur
les configurations complètes avec et sans adaptateurs et inclut donc le
gel des bases et l'agrégation des facteurs.

Chaque configuration est entraînée sur cinq graines (42, 123, 456, 789
et 1234), avec 20 véhicules, le réseau IEEE 33 bus, 200 épisodes de
24 h, une taille de minibatch de 256, un seuil de 512 transitions dans
le buffer local et une mise à jour SAC toutes les quatre transitions.
Le seuil et la fréquence d'apprentissage ont été choisis pour la
campagne pilote sur CPU. Les réglages publics de référence sont
1 000 épisodes, 2 000 transitions de chauffe et une mise à jour à chaque
transition. Le modèle de conduite facultatif est désactivé et les
sessions synthétiques démarrent à l'origine de l'épisode, comme dans
la configuration par défaut.

Le CSV de prix versionné contient 85 527 lignes et 9 503 horodatages
distincts, avec neuf lignes par horodatage. Les neuf valeurs sont
agrégées par moyenne arithmétique, puis la journée incomplète est
écartée. Les 316 premiers jours complets servent à l'entraînement et
les 79 jours suivants constituent la période de test. Le min–max est
ajusté sur les 316 jours d'entraînement. Chaque épisode d'entraînement
utilise un jour tiré dans cette première période. Le coût et la
récompense utilisent le prix normalisé réalisé, tandis que les cinq
prix fournis en entrée à l'agent sont issus du profil horaire moyen
des seuls jours d'entraînement.

Pour l'évaluation, 30 jours régulièrement espacés sont pris dans la
période réservée. Le profil de recharge des 20 véhicules et la charge
de fond sont fixés par scénario et identiques pour toutes les
politiques et graines. Chaque jour est évalué en charge nominale
et en charge renforcée de 0,8 MW. Les méthodes partagent les mêmes
données de scénario et, à graine égale, les mêmes dates et charges
de fond d'entraînement. Les actions au test sont déterministes.

## Mesures

- **Cible de charge atteinte**. Proportion des départs dont le SOC est
  supérieur ou égal à la cible propre au véhicule.
- **Déficit au départ**. Moyenne de la partie positive de la différence
  entre cible et SOC, en points de SOC, en incluant tous les départs.
- **Indice de coût**. Somme de l'énergie importée multipliée par le
  prix normalisé réalisé. L'unité de l'indice dépend de la normalisation.
- **Tension**. Proportions de couples bus–pas de temps et de pas de temps
  avec au moins un bus hors de la bande [0,90 ; 1,10] p.u. Les échecs
  de résolution du flux sont comptés séparément.
- **Rampes**. Écart-type au sein d'un épisode des différences de charge
  entre deux heures consécutives, pour la charge totale et celle des
  véhicules séparément.
- **Charge utile**. Taille des tenseurs exportés par un véhicule à
  un instant d'agrégation. Le volume total du réseau dépend également
  des échanges et de la topologie.

Les résumés moyennent d'abord les scénarios au sein de chaque
entraînement, puis les cinq graines. Les intervalles descriptifs à
95 % utilisent une loi de Student au niveau des graines, sur les
différences appariées pour les contrastes. Ils portent sur les
scénarios fixés pour cette évaluation. Le nombre de scénarios ne
remplace pas le nombre de graines indépendantes. Le régime de forte
charge reste un scénario synthétique et le test utilise un seul
réseau de distribution.

## Fichiers

| Fichier | Contenu |
| --- | --- |
| RESULTATS.md | Chiffres et interprétation de la campagne. |
| DIAGNOSTIC_SIMULATEUR_INITIAL.md | Résultats et bilan d’énergie du simulateur de départ. |
| results_feasible/ | Campagne avec bornes de puissance corrigées. |
| results/ | Campagne sur le simulateur initial, à interpréter comme diagnostic. |
| *.json par graine | Configuration, données, métriques par scénario et courbe d'entraînement de chaque run. |
| results/per_episode.csv | Une ligne par scénario et entraînement. |
| results/per_seed.csv | Moyennes au niveau de chaque entraînement. |
| results/summary.csv | Estimations par méthode et régime de charge. |
| results/paired_differences.csv | Contrastes appariés au niveau des graines. |
| grid_reference.json | Évaluation électrique du réseau seul sur les mêmes charges de fond. |
| comparaison_charge_renforcee.png | Résultats par graine pour le scénario de charge renforcée. |
| courbes_recompense_entrainement.png | Courbes d’apprentissage et médianes, avec la récompense propre à chaque configuration. |
| energy_balance_audit.csv | Bilan d'énergie par épisode et borne conservatrice de l'excès d'export. |
| battery_boundary_checks.json | Tests de puissance aux bornes et contrôle individuel d’atteignabilité. |
| battery_feasibility.patch | Correction de la puissance au sein du pipeline de comparaison. |
| pipeline.patch | Points d'instrumentation ajoutés au pipeline de Mohamed. |
| run_grid_reward_study.py | Prétraitement, scénarios communs et exécution d'un entraînement. |
| run_campaign.sh | Commandes de la campagne complète et agrégation. |

## Reproduire

Avec Python 3.12 et la variante CPU de PyTorch, depuis le dossier de
cette archive, exécuter les commandes suivantes.

    git clone https://github.com/LIMAMMohamedlimam/PFE-FDRL-EV.git
    git -C PFE-FDRL-EV checkout 12a4ff452f157d57b554f1a618ed6f1d6f004e0f
    git -C PFE-FDRL-EV apply ../pipeline.patch
    python3 -m venv .venv
    . .venv/bin/activate
    python -m pip install torch==2.7.1 --index-url https://download.pytorch.org/whl/cpu
    python -m pip install -r requirements.txt
    WORKERS=4 PYTHON=python bash run_campaign.sh PFE-FDRL-EV

Pour reproduire ensuite la campagne corrigée, appliquer la correction
par-dessus le patch d'instrumentation et lancer la même commande avec un
dossier de résultats différent.

    git -C PFE-FDRL-EV apply ../battery_feasibility.patch
    HFDRL_RESULTS_DIR="$PWD/results_feasible" WORKERS=4 PYTHON=python bash run_campaign.sh PFE-FDRL-EV

Le fichier grid_reference.json peut être reproduit à part.

    python grid_reference.py --repo PFE-FDRL-EV --output grid_reference.json

Une fois les résultats agrégés, les tableaux et figures sont obtenus avec

    python report_tables.py --directory results --original --output DIAGNOSTIC_SIMULATEUR_INITIAL.md
    python report_tables.py --directory results_feasible --output RESULTATS.md
    python plot_grid_reward_study.py --directory results_feasible --output comparaison_charge_renforcee.png
    python plot_training_rewards.py --directory results_feasible --output courbes_recompense_entrainement.png
