from pathlib import Path
import argparse
import json
import pandas as pd
import numpy as np
parser=argparse.ArgumentParser()
parser.add_argument('--directory',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
parser.add_argument('--original',action='store_true')
args=parser.parse_args()
root=Path(__file__).resolve().parent
summary=pd.read_csv(args.directory/'summary.csv')
contrasts=pd.read_csv(args.directory/'paired_differences.csv')
episodes=pd.read_csv(args.directory/'per_episode.csv')
runs=[json.loads(p.read_text()) for p in sorted(args.directory.glob('*.json')) if p.stem.rsplit('_',1)[-1].isdigit()]
energy=pd.read_csv(args.directory/'energy_balance_audit.csv')
boundary=json.loads((args.directory/'battery_boundary_checks.json').read_text())
methods={
 'fedavg_sac':'FedAvg-SAC',
 'hfdrl_no_lora':'HFDRL sans LoRA',
 'hfdrl_full':'HFDRL complet',
 'hfdrl_no_grid_reward':'HFDRL sans terme réseau',
}
outcomes={
 'target_met_pct':('Cible atteinte (%)',1),
 'mean_soc_deficit_pp':('Déficit SOC (points)',1),
 'normalized_charging_cost_index':('Indice de coût',1),
 'voltage_violation_bus_step_pct':('Bus–heures hors bande (%)',2),
 'energy_import_kwh':('Import (kWh)',1),
 'energy_export_kwh':('Export (kWh)',1),
}
def number(v,d):
 return f'{v:.{d}f}'.replace('.',',')
def metric(cond,method,key):
 return summary.query('condition == @cond and method == @method and outcome == @key').iloc[0]
def diff(cond,contrast,key):
 return contrasts.query('condition == @cond and contrast == @contrast and outcome == @key').iloc[0]

title=('# Diagnostic du simulateur initial' if args.original
       else '# Résultats pilotes après correction des bornes de batterie')
lines=[title,'',
       'Vingt entraînements au total, '
       'soit quatre configurations sur cinq graines. Chaque modèle est évalué sur '
       'les mêmes 30 jours en régime nominal et en charge renforcée. '
       'La synthèse porte sur 1 200 évaluations de 20 véhicules, avec les '
       'intervalles calculés au niveau des graines d’entraînement.',
       '','Le détail du protocole et la définition des métriques figurent dans le README.','']
for condition,heading in [('nominal','Charge nominale'),('stress','Charge renforcée de 0,8 MW')]:
 lines.extend(['## '+heading,'','| Méthode | '+' | '.join(v[0] for v in outcomes.values())+' |',
               '| --- |'+' ---: |'*len(outcomes)])
 for method,label in methods.items():
  vals=[number(metric(condition,method,k)['mean'],v[1]) for k,v in outcomes.items()]
  lines.append('| '+label+' | '+' | '.join(vals)+' |')
 lines.append('')
lines+=['## Différences appariées sous charge renforcée','',
       'La différence correspond à HFDRL complet moins la variante indiquée. '
       'Les intervalles à 95 % sont calculés à partir des cinq différences entre graines.',
       '','| Comparaison | Δ cible atteinte (points de %) | Δ déficit SOC (points) | Δ bus–heures hors bande (points de %) |',
       '| --- | ---: | ---: | ---: |']
for contrast,label in [('grid_reward_on_minus_off','Avec terme réseau moins sans terme réseau'),
                       ('lora_full_minus_no_lora','Avec LoRA moins sans LoRA')]:
 vals=[]
 for k,d in [('target_met_pct',1),('mean_soc_deficit_pp',1),('voltage_violation_bus_step_pct',2)]:
  r=diff('stress',contrast,k)
  vals.append(f'{number(r["mean"],d)} [{number(r["ci95_low"],d)} à {number(r["ci95_high"],d)}]')
 lines.append('| '+label+' | '+' | '.join(vals)+' |')

pbytes={m:{x['training']['payload_bytes_per_vehicle'] for x in runs if x['method']==m} for m in methods}
assert all(len(v)==1 for v in pbytes.values())
full=next(iter(pbytes['hfdrl_no_lora']))
lora=next(iter(pbytes['hfdrl_full']))
ref=pd.read_json(root/'grid_reference.json')
outside=float(ref[ref.condition=='stress']['voltage_violation_bus_step_pct'].mean())
nom=episodes[episodes['condition']=='nominal'].sort_values(['method','seed','date'])
stress=episodes[episodes['condition']=='stress'].sort_values(['method','seed','date'])
unchanged=np.isclose(nom.energy_import_kwh.to_numpy(),stress.energy_import_kwh.to_numpy(),
                    rtol=0.0,atol=1e-8) & np.isclose(nom.energy_export_kwh.to_numpy(),
                    stress.energy_export_kwh.to_numpy(),rtol=0.0,atol=1e-8)
lines+=['','## Diagnostics','',
       f'- Les tenseurs transmis occupent {number(full/1024,2)} Kio sans LoRA et '
       f'{number(lora/1024,2)} Kio avec LoRA par véhicule et par échange, soit '
       f'une réduction de {number(100*(1-lora/full),1)} % de la charge utile.',
       f'- Le réseau sans recharge ni décharge des véhicules présente {number(outside,2)} % '
       'de bus–heures hors bande sous charge renforcée. Dans cette référence, le '
       'signal de congestion fourni à l’agent après écrêtage atteint sa borne maximale '
       'sur tous les pas observés des deux régimes.',
       f'- La charge renforcée donne exactement la même énergie importée et exportée '
       f'que la charge nominale dans {int(unchanged.sum())} des {len(unchanged)} '
       'comparaisons de scénarios appariées par méthode et graine. '
       'Cette égalité porte sur l’énergie totale par épisode.',
       f'- Nombre d’échecs de flux observés dans les 1 200 évaluations des politiques : '
       f'{int(episodes.failed_power_flow_steps.sum())}.','']
max_abs_resid=energy.energy_balance_residual_kwh.abs().max()
if args.original:
  exceeded=energy.export_beyond_initial_plus_import_kwh>1e-8
  count=int(exceeded.sum())
  full_stress=energy[(energy.method=='hfdrl_full')&(energy.condition=='stress')]
  extra=float(full_stress.export_beyond_initial_plus_import_kwh.mean())
  lines+=['## Anomalie de conservation de l’énergie','',
          'Les résultats électriques ci-dessus documentent le défaut du simulateur initial. '
          'Le calcul de flux reçoit la puissance commandée avant la mise à jour et l’écrêtage du SOC. '
          'Un test direct reproduit une puissance enregistrée de −11 kW à SOC nul et de 10,45 kW à SOC plein.',
          f'Le bilan d’énergie montre {count} épisodes dans lesquels l’export dépasse la somme '
          'de l’import et de l’énergie initiale disponible selon la transition du simulateur. '
          f'Pour HFDRL complet sous charge renforcée, cet excès est de {number(extra,1)} kWh par épisode en moyenne.',
          'Les valeurs de charge utile restent un résultat de taille des tenseurs. '
          'Les résultats électriques du simulateur initial doivent être lus à la lumière de cette anomalie.','']
else:
  assert max_abs_resid < 1e-7,max_abs_resid
  assert abs(boundary['empty_battery_discharge']['recorded_power_kw']) < 1e-12
  assert abs(boundary['full_battery_charge']['recorded_power_kw']) < 1e-12
  reach=boundary['individual_battery_reachability']
  lines+=['## Vérification physique','',
          'La puissance appliquée est calculée avant le flux électrique et respecte les limites de la batterie. '
          f'Le résidu maximal absolu du bilan d’énergie sur les {len(energy)} évaluations '
          f'est de {max_abs_resid:.2e} kWh.',
          f'Une recharge immédiate à la puissance admissible maximale atteint {reach["target_reached_with_immediate_max_power"]} '
          f'cibles sur les {reach["cases"]} profils individuels de test avec les seules contraintes de batterie.',
          'Les résultats décrivent une campagne de 200 épisodes d’entraînement. '
          'Ils doivent être interprétés au budget d’apprentissage et avec le protocole de prix indiqués dans le README.','']
args.output.write_text('\n'.join(lines),encoding='utf-8')
