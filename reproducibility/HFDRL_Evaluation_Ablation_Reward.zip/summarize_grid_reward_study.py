"""Aggregate the paired HFDRL runs at the independent training-seed level."""
import argparse
import csv
import json
from pathlib import Path

import numpy as np
from scipy.stats import t

from run_grid_reward_study import CONDITIONS, SEEDS

OUTCOMES = (
    "evaluation_reward_common",
    "normalized_charging_cost_index",
    "mean_final_soc_pct",
    "target_met_pct",
    "mean_soc_deficit_pp",
    "energy_import_kwh",
    "energy_export_kwh",
    "mean_abs_voltage_deviation_pu",
    "min_voltage_pu",
    "voltage_violation_bus_step_pct",
    "voltage_violation_time_step_pct",
    "failed_power_flow_steps",
    "grid_ramp_sd_mw",
    "ev_ramp_sd_mw",
    "peak_grid_load_mw",
)
CONTRASTS = {
    "lora_full_minus_no_lora": ("hfdrl_full", "hfdrl_no_lora"),
    "grid_reward_on_minus_off": ("hfdrl_full", "hfdrl_no_grid_reward"),
    "full_minus_fedavg_sac": ("hfdrl_full", "fedavg_sac"),
}


def interval(values):
    n = len(values)
    mean = float(np.mean(values)) if n else None
    half = float(t.ppf(0.975, n - 1) * np.std(values, ddof=1) / np.sqrt(n)) if n > 1 else None
    return {
        "n_seeds": n,
        "mean": mean,
        "ci95_low": mean - half if half is not None else None,
        "ci95_high": mean + half if half is not None else None,
    }


def write_csv(path, records):
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", type=Path, default=Path(__file__).resolve().parent / "results")
    args = parser.parse_args()
    runs = {
        (run["method"], run["seed"]): run
        for p in sorted(args.directory.glob("*.json")) if p.stem.rsplit("_", 1)[-1].isdigit()
        for run in [json.loads(p.read_text())]
    }
    expected = {(method, seed) for method in CONDITIONS for seed in SEEDS}
    if runs.keys() != expected:
        raise ValueError(f"Run set differs: missing {expected - runs.keys()}, extra {runs.keys() - expected}")
    reference = runs[("hfdrl_full", SEEDS[0])]
    expected_scenarios = [
        (e["scenario_id"], e["condition"], e["date"], e["departures"])
        for e in reference["episodes"]
    ]
    fixed = (
        "training_episodes", "test_days", "vehicles", "sac_warmup",
        "sac_batch_size", "sac_update_every", "evaluation_grid_weight",
        "common_scenario_seed", "stress_background_load_offset_mw",
    )
    for run in runs.values():
        current_scenarios = [
            (e["scenario_id"], e["condition"], e["date"], e["departures"])
            for e in run["episodes"]
        ]
        if (
            current_scenarios != expected_scenarios
            or run["data"] != reference["data"]
            or run["code_commit"] != reference["code_commit"]
            or run.get("pipeline_sha256") != reference.get("pipeline_sha256")
            or any(run["settings"][k] != reference["settings"][k] for k in fixed)
        ):
            raise ValueError("Scenario or protocol mismatch")
        if min(run["training"]["gradient_updates_per_vehicle"]) <= 0:
            raise ValueError("At least one agent never passed replay warm-up")

    episodes = [
        {"method": method, "seed": seed, **row}
        for (method, seed), run in runs.items()
        for row in run["episodes"]
    ]
    run_summaries = []
    mean = {}
    for (method, seed), run in runs.items():
        for condition in ("nominal", "stress"):
            rows = [r for r in run["episodes"] if r["condition"] == condition]
            means = {}
            for outcome in OUTCOMES:
                vals = [r[outcome] for r in rows if r[outcome] is not None]
                means[outcome] = float(np.mean(vals)) if vals else None
            mean[method, seed, condition] = means
            run_summaries.append({"method": method, "seed": seed, "condition": condition, **means})

    summary = []
    contrasts = []
    for condition in ("nominal", "stress"):
        for outcome in OUTCOMES:
            for method in CONDITIONS:
                vals = [mean[method, seed, condition][outcome] for seed in SEEDS]
                summary.append({"condition": condition, "method": method, "outcome": outcome,
                                **interval([v for v in vals if v is not None])})
            for contrast, (first, second) in CONTRASTS.items():
                pairs = [(mean[first, seed, condition][outcome], mean[second, seed, condition][outcome])
                         for seed in SEEDS]
                deltas = [a - b for a, b in pairs if a is not None and b is not None]
                contrasts.append({"condition": condition, "contrast": contrast, "outcome": outcome,
                                  **interval(deltas)})
    write_csv(args.directory / "per_episode.csv", episodes)
    write_csv(args.directory / "per_seed.csv", run_summaries)
    write_csv(args.directory / "summary.csv", summary)
    write_csv(args.directory / "paired_differences.csv", contrasts)
    print(f"Aggregated {len(runs)} trainings and {len(episodes)} evaluation episodes.")


if __name__ == "__main__":
    main()
