"""Plot the per-seed learning curves using each configuration's own reward."""
import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from plot_grid_reward_study import COLORS, LABELS


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    runs = [json.loads(p.read_text()) for p in sorted(args.directory.glob("*_[0-9]*.json"))]
    fig, axes = plt.subplots(2, 2, figsize=(9, 5.7), sharex=True, sharey=True,
                             layout="constrained")
    window = 20
    for ax, method, color in zip(axes.flat, LABELS, COLORS, strict=True):
        chosen = sorted((run for run in runs if run["method"] == method),
                        key=lambda run: run["seed"])
        curves = np.asarray([
            np.convolve(run["training_episode_rewards"],
                        np.full(window, 1 / window), mode="valid")
            for run in chosen
        ])
        episodes = np.arange(window, window + curves.shape[1])
        for curve in curves:
            ax.plot(episodes, curve, color=color, alpha=0.3, lw=1)
        ax.plot(episodes, np.median(curves, axis=0), color=color, lw=2.1)
        weight = chosen[0]["settings"]["training_grid_weight"]
        ax.set_title(f'{LABELS[method]}  ·  wᵍ = {str(weight).replace(".", ",")}',
                     fontsize=10)
        ax.grid(color="#dce4ea", linewidth=0.7)
        ax.spines[["top", "right"]].set_visible(False)
    fig.suptitle("Récompense d’entraînement par configuration", fontweight="bold")
    fig.supylabel("Récompense cumulée de la flotte par épisode")
    fig.supxlabel("Épisode d’entraînement  ·  moyenne mobile sur 20 épisodes\n"
                 "Une courbe par graine et médiane en trait foncé. "
                 "La récompense change avec le poids réseau.", fontsize=9)
    fig.savefig(args.output, dpi=210, facecolor="white")
    plt.close(fig)


if __name__ == "__main__":
    main()
