# Résultats pilotes après correction des bornes de batterie

Vingt entraînements au total, soit quatre configurations sur cinq graines. Chaque modèle est évalué sur les mêmes 30 jours en régime nominal et en charge renforcée. La synthèse porte sur 1 200 évaluations de 20 véhicules, avec les intervalles calculés au niveau des graines d’entraînement.

Le détail du protocole et la définition des métriques figurent dans le README.

## Charge nominale

| Méthode | Cible atteinte (%) | Déficit SOC (points) | Indice de coût | Bus–heures hors bande (%) | Import (kWh) | Export (kWh) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| FedAvg-SAC | 0,0 | 78,6 | 2,5 | 0,00 | 13,4 | 193,8 |
| HFDRL sans LoRA | 0,0 | 83,1 | 0,3 | 0,00 | 1,6 | 238,6 |
| HFDRL complet | 0,0 | 89,7 | 0,0 | 0,00 | 0,0 | 320,5 |
| HFDRL sans terme réseau | 31,8 | 14,6 | 123,7 | 0,00 | 662,4 | 0,0 |

## Charge renforcée de 0,8 MW

| Méthode | Cible atteinte (%) | Déficit SOC (points) | Indice de coût | Bus–heures hors bande (%) | Import (kWh) | Export (kWh) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| FedAvg-SAC | 0,0 | 78,6 | 2,5 | 1,15 | 13,4 | 193,8 |
| HFDRL sans LoRA | 0,0 | 83,1 | 0,3 | 1,12 | 1,6 | 238,6 |
| HFDRL complet | 0,0 | 89,7 | 0,0 | 1,11 | 0,0 | 320,5 |
| HFDRL sans terme réseau | 31,8 | 14,6 | 123,7 | 1,77 | 662,4 | 0,0 |

## Différences appariées sous charge renforcée

La différence correspond à HFDRL complet moins la variante indiquée. Les intervalles à 95 % sont calculés à partir des cinq différences entre graines.

| Comparaison | Δ cible atteinte (points de %) | Δ déficit SOC (points) | Δ bus–heures hors bande (points de %) |
| --- | ---: | ---: | ---: |
| Avec terme réseau moins sans terme réseau | -31,8 [-69,2 à 5,7] | 75,1 [60,8 à 89,4] | -0,66 [-0,88 à -0,44] |
| Avec LoRA moins sans LoRA | 0,0 [0,0 à 0,0] | 6,6 [-3,1 à 16,3] | -0,01 [-0,10 à 0,09] |

## Diagnostics

- Les tenseurs transmis occupent 217,52 Kio sans LoRA et 26,70 Kio avec LoRA par véhicule et par échange, soit une réduction de 87,7 % de la charge utile.
- Le réseau sans recharge ni décharge des véhicules présente 1,26 % de bus–heures hors bande sous charge renforcée. Dans cette référence, le signal de congestion fourni à l’agent après écrêtage atteint sa borne maximale sur tous les pas observés des deux régimes.
- La charge renforcée donne exactement la même énergie importée et exportée que la charge nominale dans 600 des 600 comparaisons de scénarios appariées par méthode et graine. Cette égalité porte sur l’énergie totale par épisode.
- Nombre d’échecs de flux observés dans les 1 200 évaluations des politiques : 0.

## Vérification physique

La puissance appliquée est calculée avant le flux électrique et respecte les limites de la batterie. Le résidu maximal absolu du bilan d’énergie sur les 1 200 évaluations est de 9,09 × 10⁻¹³ kWh.
Une recharge immédiate à la puissance admissible maximale atteint 600 cibles sur les 600 profils individuels de test avec les seules contraintes de batterie.
Les résultats décrivent une campagne de 200 épisodes d’entraînement. Ils doivent être interprétés au budget d’apprentissage et avec le protocole de prix indiqués dans le README.

## Interprétation

Le HFDRL complet n’atteint aucune cible sur les cinq graines. Il importe
0 kWh et exporte 320,5 kWh par épisode en moyenne. Sa baisse de la part
des bus–heures hors bande intervient donc dans un scénario où la flotte
décharge ses batteries et ne fournit pas le service de recharge.
Un indice de coût nul correspond ici à une absence d’achat d’énergie.

L’ablation du terme réseau ramène le déficit de charge moyen de 89,7 à
14,6 points de SOC. La proportion de cibles atteintes varie de 0,7 à
71,8 % selon la graine. L’intervalle apparié pour cette proportion
recouvre zéro. À ce budget, les résultats établissent le comportement
observé sur les cinq graines et montrent la variabilité de la politique
sans pénalité réseau.

La réduction de 87,7 % de la taille par mise à jour LoRA est vérifiée
séparément. Avant de tirer une conclusion sur le compromis entre
communication et qualité de recharge, il faudrait répéter la comparaison
sur le simulateur corrigé avec le budget de référence et confronter les
configurations à un service de recharge comparable.
