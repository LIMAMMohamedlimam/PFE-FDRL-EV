#!/usr/bin/env bash
set -euo pipefail
repo=$(cd "$1" && pwd)
study=$(cd "$(dirname "$0")" && pwd)
workers=$(printenv WORKERS || printf 4)
python=$(printenv PYTHON || printf python3)
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
results=$(printenv HFDRL_RESULTS_DIR || printf '%s/results' "$study")
export HFDRL_STUDY="$study" HFDRL_REPO="$repo" HFDRL_PYTHON="$python" HFDRL_RESULTS="$results"
mkdir -p "$results/logs"
for seed in 42 123 456 789 1234; do
    for method in fedavg_sac hfdrl_no_lora hfdrl_full hfdrl_no_grid_reward; do
        printf '%s %s\n' "$seed" "$method"
    done
done | xargs -n 2 -P "$workers" bash -c '
    set -e
    seed=$1
    method=$2
    printf -v tag "%s_%s" "$method" "$seed"
    PYTHONHASHSEED="$seed" "$HFDRL_PYTHON" "$HFDRL_STUDY/run_grid_reward_study.py" \
        --repo "$HFDRL_REPO" --method "$method" --seed "$seed" --episodes 200 \
        --warmup 512 --update-every 4 --test-days 30 \
        --output "$HFDRL_RESULTS/$tag.json" > "$HFDRL_RESULTS/logs/$tag.log" 2>&1
    printf "Completed %s\n" "$tag"
' _
"$python" "$study/summarize_grid_reward_study.py" --directory "$results"
"$python" "$study/audit_energy_balance.py" --repo "$repo" --directory "$results"
"$python" "$study/check_battery.py" --repo "$repo" --output "$results/battery_boundary_checks.json"
