"""Check battery power boundaries and physical reachability on test profiles."""
import argparse
import json
import sys
from pathlib import Path

import numpy as np

from run_grid_reward_study import SCENARIO_SEED


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    sys.path.insert(0, str(args.repo.resolve()))
    from env.EVClientEnv import EVClientEnv
    from training.ComparisonPipeline import _action_to_power
    from utils.DataLoader import DataGenerator
    from utils.config_loader import get_config

    config = get_config("env")
    config["driver_behavior"]["enabled"] = False
    env = EVClientEnv({"capacity": config.get("battery_capacity", 60.0), "dt": 1.0})
    checks = {}
    for name, initial_soc, action in [
        ("empty_battery_discharge", 0.0, -1.0),
        ("near_empty_battery_discharge", 0.01, -1.0),
        ("near_full_battery_charge", 0.99, 1.0),
        ("full_battery_charge", 1.0, 1.0),
    ]:
        env.reset(initial_soc=initial_soc)
        requested = action * env._get_max_power(env.soc)
        applied = _action_to_power(None, action, env, "sac")
        _, _, final_soc, cost = env.step(applied, 0.0, 0.0, 0.5)
        checks[name] = {
            "commanded_power_kw": requested,
            "power_sent_to_grid_kw": applied,
            "recorded_power_kw": env.episode_log[-1]["charging_power"],
            "final_soc": float(final_soc),
            "normalized_cost": float(cost),
        }

    np.random.seed(SCENARIO_SEED)
    reached = count = 0
    for _ in range(30):
        for profile in DataGenerator.get_nhts_profile(20):
            target = profile["soc_req"]
            env.reset(initial_soc=profile["soc_init"], soc_req=target,
                      t_dep=profile["duration"])
            for _ in range(max(1, profile["duration"])):
                applied = _action_to_power(None, 1.0, env, "sac")
                _, done, _, _ = env.step(applied, 0.0, 0.0, 0.0)
                if done or env.soc >= target:
                    break
            count += 1
            reached += int(env.soc >= target)
    checks["individual_battery_reachability"] = {
        "cases": count,
        "target_reached_with_immediate_max_power": reached,
        "scope": "Common test profiles, battery physics only, no feeder constraint",
    }
    args.output.write_text(json.dumps(checks, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
