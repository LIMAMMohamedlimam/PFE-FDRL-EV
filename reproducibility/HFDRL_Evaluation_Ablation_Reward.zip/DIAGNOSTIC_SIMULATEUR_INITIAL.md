# Diagnostic du simulateur initial

Vingt entraînements au total, soit quatre configurations sur cinq graines. Chaque modèle est évalué sur les mêmes 30 jours en régime nominal et en charge renforcée. La synthèse porte sur 1 200 évaluations de 20 véhicules, avec les intervalles calculés au niveau des graines d’entraînement.

Le détail du protocole et la définition des métriques figurent dans le README.

## Charge nominale

| Méthode | Cible atteinte (%) | Déficit SOC (points) | Indice de coût | Bus–heures hors bande (%) | Import (kWh) | Export (kWh) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| FedAvg-SAC | 74,5 | 8,6 | 198,5 | 0,00 | 1058,9 | 0,0 |
| HFDRL sans LoRA | 71,8 | 4,3 | 191,4 | 0,00 | 1020,3 | 0,0 |
| HFDRL complet | 0,0 | 84,2 | 0,0 | 0,00 | 0,0 | 671,4 |
| HFDRL sans terme réseau | 30,6 | 14,9 | 127,0 | 0,00 | 677,9 | 0,0 |

## Charge renforcée de 0,8 MW

| Méthode | Cible atteinte (%) | Déficit SOC (points) | Indice de coût | Bus–heures hors bande (%) | Import (kWh) | Export (kWh) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| FedAvg-SAC | 74,5 | 8,6 | 198,5 | 2,14 | 1058,9 | 0,0 |
| HFDRL sans LoRA | 71,8 | 4,3 | 191,4 | 2,11 | 1020,3 | 0,0 |
| HFDRL complet | 0,0 | 84,2 | 0,0 | 0,95 | 0,0 | 671,4 |
| HFDRL sans terme réseau | 30,6 | 14,9 | 127,0 | 1,78 | 677,9 | 0,0 |

## Différences appariées sous charge renforcée

La différence correspond à HFDRL complet moins la variante indiquée. Les intervalles à 95 % sont calculés à partir des cinq différences entre graines.

| Comparaison | Δ cible atteinte (points de %) | Δ déficit SOC (points) | Δ bus–heures hors bande (points de %) |
| --- | ---: | ---: | ---: |
| Avec terme réseau moins sans terme réseau | -30,6 [-66,8 à 5,7] | 69,2 [50,2 à 88,3] | -0,83 [-1,27 à -0,39] |
| Avec LoRA moins sans LoRA | -71,8 [-110,8 à -32,8] | 79,9 [71,8 à 88,1] | -1,16 [-1,40 à -0,91] |

## Diagnostics

- Les tenseurs transmis occupent 217,52 Kio sans LoRA et 26,70 Kio avec LoRA par véhicule et par échange, soit une réduction de 87,7 % de la charge utile.
- Le réseau sans recharge ni décharge des véhicules présente 1,26 % de bus–heures hors bande sous charge renforcée. Dans cette référence, le signal de congestion fourni à l’agent après écrêtage atteint sa borne maximale sur tous les pas observés des deux régimes.
- La charge renforcée donne exactement la même énergie importée et exportée que la charge nominale dans 600 des 600 comparaisons de scénarios appariées par méthode et graine. Cette égalité porte sur l’énergie totale par épisode.
- Nombre d’échecs de flux observés dans les 1 200 évaluations des politiques : 0.

## Anomalie de conservation de l’énergie

Les résultats électriques ci-dessus documentent le défaut du simulateur initial. Le calcul de flux reçoit la puissance commandée avant la mise à jour et l’écrêtage du SOC. Un test direct reproduit une puissance enregistrée de −11 kW à SOC nul et de 10,45 kW à SOC plein.
Le bilan d’énergie montre 146 épisodes dans lesquels l’export dépasse la somme de l’import et de l’énergie initiale disponible selon la transition du simulateur. Pour HFDRL complet sous charge renforcée, cet excès est de 406,5 kWh par épisode en moyenne.
Les valeurs de charge utile restent un résultat de taille des tenseurs. Les résultats électriques du simulateur initial doivent être lus à la lumière de cette anomalie.
