"""Compute a feeder-only reference for the same fixed background loads."""
import argparse
import json
import sys
from pathlib import Path

import numpy as np

from run_grid_reward_study import HOURS, SCENARIO_SEED


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--test-days", type=int, default=30)
    args = parser.parse_args()

    sys.path.insert(0, str(args.repo.resolve()))
    from env.GridEnv import GridEnv

    rng = np.random.default_rng(SCENARIO_SEED)
    grid = GridEnv()
    rows = []
    for day in range(args.test_days):
        load = rng.normal(3.5, 0.2, HOURS)
        for condition, offset in (("nominal", 0.0), ("stress", 0.8)):
            grid.reset()
            traces = []
            failures = 0
            for power in load + offset:
                _, info = grid.step({}, float(power))
                if info["converged"]:
                    traces.append(grid.get_grid_state().copy())
                else:
                    failures += 1
            voltages = np.asarray(traces)
            rows.append({
                "day_index": day,
                "condition": condition,
                "voltage_violation_bus_step_pct": float(
                    100 * np.mean((voltages < 0.90) | (voltages > 1.10))
                ),
                "mean_abs_voltage_deviation_pu": float(np.abs(voltages - 1).mean()),
                "min_voltage_pu": float(voltages.min()),
                "congestion_feature_saturated_time_step_pct": float(
                    100 * np.mean(np.abs(voltages - 1).max(axis=1) >= 0.05)
                ),
                "failed_power_flow_steps": failures,
            })
    args.output.write_text(json.dumps(rows, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
