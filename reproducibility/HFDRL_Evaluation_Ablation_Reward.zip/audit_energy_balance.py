"""Audit battery energy conservation in completed runs."""
import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np

from run_grid_reward_study import SCENARIO_SEED


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--directory", type=Path, default=Path(__file__).resolve().parent / "results")
    args = parser.parse_args()
    sys.path.insert(0, str(args.repo.resolve()))
    from utils.DataLoader import DataGenerator

    files = sorted(p for p in args.directory.glob("*.json") if p.stem.rsplit("_",1)[-1].isdigit())
    if not files:
        raise ValueError("Expected at least one training result")
    rows = []
    for file in files:
        run = json.loads(file.read_text())
        np.random.seed(SCENARIO_SEED)
        initial = [
            60.0 * sum(profile["soc_init"] for profile in DataGenerator.get_nhts_profile(run["settings"]["vehicles"]))
            for _ in range(run["settings"]["test_days"])
        ]
        for e in run["episodes"]:
            start_kwh = initial[e["scenario_id"] // 2]
            end_kwh = e["mean_final_soc_pct"] / 100 * e["departures"] * 60.0
            imported = e["energy_import_kwh"]
            exported = e["energy_export_kwh"]
            rows.append({
                "method": run["method"], "seed": run["seed"], "scenario_id": e["scenario_id"],
                "condition": e["condition"], "initial_battery_kwh": start_kwh,
                "final_battery_kwh": end_kwh, "recorded_import_kwh": imported, "recorded_export_kwh": exported,
                "energy_balance_residual_kwh": end_kwh - start_kwh - 0.95 * (imported - exported),
                "export_beyond_initial_plus_import_kwh": max(0.0, exported - imported - start_kwh / 0.95),
            })
    with (args.directory / "energy_balance_audit.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(f"Checked battery energy in {len(rows)} evaluation episodes from {len(files)} trainings.")


if __name__ == "__main__":
    main()
