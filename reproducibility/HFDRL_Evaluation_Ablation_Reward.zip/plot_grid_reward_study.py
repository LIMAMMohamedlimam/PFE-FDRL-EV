"""Plot seed-level charging and voltage outcomes under the stress condition."""
import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

LABELS = {
    "fedavg_sac": "FedAvg-SAC",
    "hfdrl_no_lora": "HFDRL sans LoRA",
    "hfdrl_full": "HFDRL complet",
    "hfdrl_no_grid_reward": "HFDRL sans terme réseau",
}
COLORS = ("#33496d", "#137c7b", "#a84628", "#91772b")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", type=Path, default=Path(__file__).resolve().parent / "results")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    data = pd.read_csv(args.directory / "per_seed.csv")
    stress = data[data["condition"] == "stress"]
    measures = [
        ("target_met_pct", "Départs avec cible atteinte (%)"),
        ("voltage_violation_bus_step_pct", "Bus–heures hors bande (%)"),
        ("energy_export_kwh", "Énergie exportée (kWh/épisode)"),
    ]
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9})
    fig, axes = plt.subplots(1, 3, figsize=(10.4, 3.7), sharey=True, layout="constrained")
    for ax, (measure, label) in zip(axes, measures, strict=True):
        for pos, method in enumerate(LABELS):
            rows = stress[stress["method"] == method].sort_values("seed")
            values = rows[measure].to_numpy()
            offsets = np.linspace(-0.14, 0.14, len(values))
            ax.scatter(values, pos + offsets, color=COLORS[pos], s=22, alpha=0.65, zorder=3)
            ax.plot(float(values.mean()), pos, marker="D", color=COLORS[pos],
                    markeredgecolor="#111b26", markersize=6, zorder=4)
        ax.set_xlabel(label)
        if measure == "target_met_pct":
            ax.set_xticks([0, 25, 50, 75, 100])
            ax.set_xlim(-3, 103)
        ax.set_yticks(range(len(LABELS)), list(LABELS.values()))
        ax.xaxis.grid(True, color="#dce4ea", lw=0.65)
        ax.spines[["top", "right", "left"]].set_visible(False)
        ax.tick_params(axis="y", length=0)
    axes[0].invert_yaxis()
    fig.suptitle("Recharge et tension sous charge renforcée", fontsize=13, fontweight="bold")
    fig.supxlabel("Un point par graine d’entraînement. Le losange représente la moyenne.", fontsize=9)
    output = args.output or args.directory.parent / "comparaison_charge_renforcee.png"
    fig.savefig(output, dpi=220, facecolor="white")
    plt.close(fig)


if __name__ == "__main__":
    main()
